package helloworld.simplilearn.com.listdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ProductActivity extends AppCompatActivity {
    private ListView listViewCust;
    private String[] productNameList = {
            "Dell","Mac","Lenevo","Dell","Mac","Lenevo","Dell","Mac","Lenevo","Dell","Mac","Lenevo","Dell","Mac","Lenevo",
            "Dell","Mac","Lenevo","Dell","Mac","Lenevo","Dell","Mac","Lenevo","Dell","Mac","Lenevo"
    };

    private String[] productPriceList = {
            "35000","70000","30000","35000","70000","30000","35000","70000","30000","35000","70000","30000","35000","70000","30000",
            "35000","70000","30000","35000","70000","30000","35000","70000","30000","35000","70000","30000"
    };

    private Integer[] productImageList = {R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
            R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
            R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
            R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
            R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
            R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
            R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
            R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
            R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac};

    MyAdapter myAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);
        listViewCust = findViewById(R.id.listViewCustom);
        myAdapter = new MyAdapter(this,productNameList,productPriceList,productImageList);
        listViewCust.setAdapter(myAdapter);


    }
}
