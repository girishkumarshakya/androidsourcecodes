package helloworld.simplilearn.com.listdemo;

/**
 * Created by girishkumarshakya on 11/02/18.
 */

public class Product {
    private String[] productNameList;
    private String[] productPriceList;
    private Integer[] productImageList;

    public String[] getProductNameList() {
        String[] productName = {
                "Dell","Mac","Lenevo","Dell","Mac","Lenevo","Dell","Mac","Lenevo","Dell","Mac","Lenevo","Dell","Mac","Lenevo",
                "Dell","Mac","Lenevo","Dell","Mac","Lenevo","Dell","Mac","Lenevo","Dell","Mac","Lenevo"
        };
        productNameList = productName;
        return productNameList;
    }

    public String[] getProductPriceList() {
        String[] productPrice = {
                "35000","70000","30000","35000","70000","30000","35000","70000","30000","35000","70000","30000","35000","70000","30000",
                "35000","70000","30000","35000","70000","30000","35000","70000","30000","35000","70000","30000"
        };
        productPriceList = productPrice;
        return productPriceList;
    }

    public Integer[] getProductImageList() {
        Integer[] productImage = {R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
                R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
                R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
                R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
                R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
                R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
                R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
                R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac,
                R.drawable.ic_action_mac,R.drawable.ic_action_mac,R.drawable.ic_action_mac};
        productImageList = productImage;
        return productImageList;
    }
}
