package helloworld.simplilearn.com.listdemo;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by girishkumarshakya on 11/02/18.
 */

public class MyAdapter extends BaseAdapter {
    private Context context;
    private String[] productNameList;
    private String[] productPriceList;
    private Integer[] productImageList;
    private LayoutInflater inflater;

    public MyAdapter(Context context,
                     String[] productNameList,
                     String[] productPriceList,
                     Integer[] productImageList) {
        this.context = context;
        this.productImageList = productImageList;
        this.productNameList = productNameList;
        this.productPriceList = productPriceList;
        inflater = LayoutInflater.from(context);

    }

    @Override
    public int getCount() {
        Log.d("MyAdapter","getCount ");
        return productNameList.length;
    }

    @Override
    public Object getItem(int i) {
        Log.d("MyAdapter","getItem()"+productNameList[i]);
        return productNameList[i];
    }

    @Override
    public long getItemId(int i) {
        Log.d("MyAdapter","getItemId "+i);
        return i;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        Log.d("MyAdapter","getView() "+position);

        view = inflater.inflate(R.layout.list_item_custom,null);


        ImageView imageView = view.findViewById(R.id.imageView);
        final TextView textViewProName = view.findViewById(R.id.textViewProductName);
        TextView textViewProPrice = view.findViewById(R.id.textViewProductPrice);
        CheckBox checkBox = view.findViewById(R.id.checkBox);

        imageView.setImageResource(productImageList[position]);
        textViewProName.setText(productNameList[position]);
        textViewProPrice.setText(productPriceList[position]);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    Toast.makeText(context, textViewProName.getText().toString()+ "isChecked", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(context, textViewProName.getText().toString()+ "isUnchecked", Toast.LENGTH_SHORT).show();
                }
            }
        });


        return view;
    }
}
