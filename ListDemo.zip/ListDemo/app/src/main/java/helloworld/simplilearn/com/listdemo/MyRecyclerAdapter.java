package helloworld.simplilearn.com.listdemo;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by girishkumarshakya on 11/02/18.
 */

public class MyRecyclerAdapter extends RecyclerView.Adapter<MyRecyclerAdapter.MyViewHolder> {

    private Context context;
    private String[] productNameList;
    private String[] productPriceList;
    private Integer[] productImageList;
    private LayoutInflater inflater;

    public MyRecyclerAdapter(Context context,
                     String[] productNameList,
                     String[] productPriceList,
                     Integer[] productImageList) {
        this.context = context;
        this.productImageList = productImageList;
        this.productNameList = productNameList;
        this.productPriceList = productPriceList;
        inflater = LayoutInflater.from(context);

    }

    @Override
    public MyRecyclerAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Log.d("MyRecyclerAdapter","onCreateViewHolder");
        View view = inflater.inflate(R.layout.list_item_custom,null);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final MyRecyclerAdapter.MyViewHolder holder, int position) {
        Log.d("MyRecyclerAdapter","onBindViewHolder "+position);
        holder.imageView.setImageResource(productImageList[position]);
        holder.textViewProName.setText(productNameList[position]);
        holder.textViewProPrice.setText(productPriceList[position]);
        holder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    Toast.makeText(context, holder.textViewProName.getText().toString()+ "isChecked", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(context, holder.textViewProName.getText().toString()+ "isUnchecked", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        Log.d("MyRecyclerAdapter","getItemCount()");
        return productNameList.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textViewProName;
        TextView textViewProPrice;
        CheckBox checkBox;
        public MyViewHolder(View view) {
            super(view);
            Log.d("MyRecyclerAdapter","MyViewHolder(View view)");
            imageView = view.findViewById(R.id.imageView);
            textViewProName = view.findViewById(R.id.textViewProductName);
            textViewProPrice = view.findViewById(R.id.textViewProductPrice);
            checkBox = view.findViewById(R.id.checkBox);
        }
    }
}
