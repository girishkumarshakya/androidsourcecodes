package helloworld.simplilearn.com.listdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

public class ProductRecycleActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private Product product;
    private RecyclerView.LayoutManager layoutManager;
    private MyRecyclerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_recycle);
        layoutManager = new LinearLayoutManager(this);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);

        product = new Product();
        adapter = new MyRecyclerAdapter(this,product.getProductNameList(),product.getProductPriceList(),product.getProductImageList());
        recyclerView.setAdapter(adapter);

    }
}
